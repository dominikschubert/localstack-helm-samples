def handler(event, ctx):
    print("hello world")
    return "hello k8s"
